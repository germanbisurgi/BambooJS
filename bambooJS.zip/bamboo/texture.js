var Texture = function (pName, pImage, pX, pY, pWidth, pHeight) {
    "use strict";
    var self = this;

    self.name = pName;
    self.image = pImage;
    self.x = pX;
    self.y = pY;
    self.width = pWidth;
    self.height = pHeight;
};